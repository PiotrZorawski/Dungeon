var x = 5 + 7;
var sizeX = 4;
var sizeY = 8;
var mapSize = sizeX * sizeY;


function popup(){
	document.getElementById("demo").innerHTML = x;
	}
	
function randomGeneretarTrueOrFalse(){
	var x = Math.floor(Math.random() * 2)
	if (x === 0){
		return false;
	} else{
		return true;
	}
}
	
function makeRooms(){
	var rooms = [];
	var tempRooms = [];
	var Room = function(u,d,r,l){
	this.up = u
	this.down = d
	this.right = r
	this.left = l
	}
	
	for(j=1; j <= sizeY; j++){
		for (i=0; i < sizeX; i++){
			
			tempRooms.push(new Room(randomGeneretarTrueOrFalse(), true, randomGeneretarTrueOrFalse(), false));
		}
		rooms.push(tempRooms);
	}
	document.getElementById("roomNumber").innerHTML = rooms[1][1].down;
	return rooms;
}

function testMadeRooms(){
	var roomsNumber = 0
	var checkedRoomsNumber = 0
	var connectedRoomsNumber = 0
	
	
	
	roomsNumber = rooms.length;
	
	document.getElementById("roomNumber").innerHTML = rooms.length;
}